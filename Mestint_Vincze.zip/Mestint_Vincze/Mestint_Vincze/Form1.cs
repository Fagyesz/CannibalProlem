﻿using MestInt.Keretrendszer;

namespace MestInt
{
    public partial class Form1 : Form
    {

        int szerzetes;
        int kannibal;
        int korlat;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            updatedVar();
            Csúcs startCsúcs;
            GráfKereső kereső;
            startCsúcs = new Csúcs(new SzerzetesekÉsKannibálokÁllapot(szerzetes, kannibal));
            kereső = new BackTrack(startCsúcs, korlat, true);
            richTextBox1.Text=kereső.megoldásKiírásaForms(kereső.Keresés());
        }

        private void updatedVar()
        {
            szerzetes=int.Parse(comboBox1.Text);
            kannibal = int.Parse(comboBox2.Text);
            korlat = int.Parse(comboBox3.Text);
        }
    }
}